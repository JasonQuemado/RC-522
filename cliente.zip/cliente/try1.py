import gi
import requests
import threading
import json
import rfid_rc522
import os

import RPi.GPIO as GPIO
from gi.repository import Gtk, Gdk, GLib

gi.require_version("Gtk", "3.0")

SERVER_URL = "http://localhost:55555"

class CourseManager(Gtk.Window):
    def __init__(self):
        super().__init__(title="Visualizador Atenea")
        self.set_default_size(800, 500)
        self.set_border_width(10)
        self.rfid = rfid_rc522.Rfid()

        self.load_css()

        self.logged_in = False
        self.student_name = ""
        self.student_id = ""

        self.layout = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(self.layout)

        self.loginScreen()

    def load_css(self):
        try:
            css_path = os.path.abspath("cssGraphic.css")
            css_provider = Gtk.CssProvider()
            css_provider.load_from_path(css_path)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
            print(f"CSS cargado correctamente desde: {css_path}")
        except Exception as e:
            print(f"Error cargando CSS: {e}")

    def limpiarLayout(self):
        for widget in self.layout.get_children():
            self.layout.remove(widget)

    def loginScreen(self):
        self.limpiarLayout()

        contenedorCentrado = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        contenedorCentrado.set_valign(Gtk.Align.CENTER)
        contenedorCentrado.set_halign(Gtk.Align.CENTER)

        self.botonLogin = Gtk.Button()
        botonLoginShow = Gtk.Label()
        botonLoginShow.set_justify(Gtk.Justification.CENTER)
        botonLoginShow.set_markup("<span>Please, log in with your university card</span>")
        self.botonLogin.add(botonLoginShow)
        self.botonLogin.set_name("main-button")
        self.botonLogin.set_size_request(400, 150)

        contenedorCentrado.pack_start(self.botonLogin, False, False, 0)
        self.layout.pack_start(contenedorCentrado, True, True, 0)
        self.show_all()

        threading.Thread(target=self._leerTarjeta, daemon=True).start()

    def _leerTarjeta(self):
        try:
            uid = self.rfid.read_uid()
            if uid:
                GLib.idle_add(self.mostrar_uid, uid)
            else:
                GLib.idle_add(self.show_error_dialog, "No se detectó ninguna tarjeta")
        except Exception as e:
            print(f"Error: {e}")
            GLib.idle_add(self.show_error_dialog, "Error al leer la tarjeta")

    def mostrar_uid(self, uid):
        self.student_id = uid
        self.student_name = self.get_student_name(uid)
        if self.student_name:
            self.build_main_screen()
        else:
            self.show_error_dialog("UID no encontrado.")

    def show_error_dialog(self, message):
        dialog = Gtk.MessageDialog(self, 0, Gtk.MessageType.ERROR,
                                   Gtk.ButtonsType.CLOSE, "Access denied")
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def get_student_name(self, uid):
        try:
            response = requests.get(f"{SERVER_URL}/students?student_id={uid}")
            if response.status_code == 200:
                data = response.json()
                if data:
                    return data[0]["name"]
        except Exception as e:
            print(f"Error connecting to server: {e}")
        return None

    def build_main_screen(self):
        self.limpiarLayout()

        contenedor = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        saludo = Gtk.Label(label=f"Bienvenido {self.student_name}")
        saludo.set_halign(Gtk.Align.START)
        contenedor.pack_start(saludo, False, False, 0)

        self.query_entry = Gtk.Entry()
        self.query_entry.set_placeholder_text("Buscar: tasks, timetables, marks...")
        self.query_entry.connect("activate", self.on_query_entered)
        contenedor.pack_start(self.query_entry, False, False, 0)

        self.result_grid = Gtk.Grid()
        self.result_grid.set_column_spacing(10)
        self.result_grid.set_row_spacing(5)
        contenedor.pack_start(self.result_grid, True, True, 0)

        self.layout.pack_start(contenedor, True, True, 10)
        self.show_all()

    def on_query_entered(self, entry):
        query = entry.get_text()
        threading.Thread(target=self.fetch_query_result, args=(query,), daemon=True).start()

    def fetch_query_result(self, query):
        try:
            response = requests.get(f"{SERVER_URL}/{query}")
            if response.status_code == 200:
                data = response.json()
                Gtk.idle_add(self.display_results, query, data)
            else:
                print("Error en la petición")
        except Exception as e:
            print(f"Error: {e}")

    def display_results(self, query, data):
        for child in self.result_grid.get_children():
            self.result_grid.remove(child)

        if not data:
            return

        headers = list(data[0].keys())
        for i, header in enumerate(headers):
            label = Gtk.Label(label=header)
            label.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse("blue"))
            self.result_grid.attach(label, i, 0, 1, 1)

        for row_idx, row in enumerate(data):
            for col_idx, key in enumerate(headers):
                value = str(row[key])
                self.result_grid.attach(Gtk.Label(label=value), col_idx, row_idx + 1, 1, 1)

        self.show_all()

if __name__ == "__main__":
    win = CourseManager()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
